$(document).ready(function(){
var totalScriptCount =  $("#totalScriptCountHidden").text();
$("#totalscriptactual").text(totalScriptCount);
var passScriptCount =  $("#passScriptCountHidden").text();
//$("#passCountactual").text(passCount);
var failScriptCount =  $("#failScriptCountHidden").text();
//$("#failCountactual").text(failCount);
var norunScriptCount =  $("#norunScriptCountHidden").text();
//$("#norunCountactual").text(norunCount);
var batchendtime = $("#batchendtimehidden").text();
$("#batchendtimeactual").text(batchendtime);
var batchrunduration = $("#batchrundurationhidden").text();
$("#batchrundurationactual").text(batchrunduration);

var analTot = [passScriptCount * 1, failScriptCount * 1, norunScriptCount * 1]

var pass = analTot[0];
var fail = analTot[1];
var norun = analTot[2];


window.onload = function () {
	CanvasJS.addColorSet("greenShades",
                [//colorSet Array
                "#7fba00",
                "#d81e05",
                "#FFFF00"                
                ]);
	var chart = new CanvasJS.Chart("chartContainer",
	{
			colorSet: "greenShades",
		
		title:{
			text: "Details of Execution"
		},
		legend: {
			maxWidth: 500,
			itemWidth: 80,
			fontSize : 12,
			fontFamily : "GE Inspira",
			verticalAlign: "top",
			horizontalAlign: "center"
			
		},
		data: [
		{        
			type: "pie",
			indexLabelFontFamily: "GE Inspira",       
			indexLabelFontSize: 15,
			indexLabelFontWeight: "bold",
			startAngle:0,
			//indexLabelFontColor: "Blue",       
			indexLabelLineColor: "black", 
			indexLabelPlacement: "outside", 
			toolTipContent: "<strong>{name}: {y} Script</strong>",
			showInLegend: true,
			indexLabel: "#percent%",
			dataPoints: [
				{ y: pass, name : "Passed" ,indexLabel: "Passed",indexLabelFontColor:"Green" ,legendMarkerType: "triangle"},
				{ y: fail, name : "Failed", indexLabel: "Failed" ,indexLabelFontColor:"Red",legendMarkerType: "square"},
				//{ y: norun, name :"No Run",indexLabel: "No Run" ,indexLabelFontColor:"Black",legendMarkerType: "circle"},
			]
		}
		]
	});
	chart.render();
}});

$(function(){

var appendthis =  ("<div class='modal-overlay js-modal-close'></div>");

	$('a[data-modal-id]').click(function(e) {
		e.preventDefault();
    $("body").append(appendthis);
    $(".modal-overlay").fadeTo(500, 0.7);
    //$(".js-modalbox").fadeIn(500);
		var modalBox = $(this).attr('data-modal-id');
		$('#'+modalBox).fadeIn($(this).data());
	});  
		
$(".js-modal-close, .modal-overlay").click(function() {
    $(".modal-box, .modal-overlay").fadeOut(500, function() {
        $(".modal-overlay").remove();
    });
 
});
 
$(window).resize(function() {
    $(".modal-box").css({
        top: ($(window).height() - $(".modal-box").outerHeight()) / 2,
        left: ($(window).width() - $(".modal-box").outerWidth()) / 2
    });
});
 
$(window).resize();
 
});