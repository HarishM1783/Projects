//***********************************************************************************************************************************************************************************
//Function Name        - javascript & Jquery functions to draw chart and handle popups in the HTML report
//Description 			- NA
//Input Parameters      	- NA
//Pre-Condition          - N/A
//Post - Condition:      - N/A
//Return Value           - NA
//Author                 - Gaurav  Saxena
//Date                   - 7 Sep 2015
//***********************************************************************************************************************************************************************************
$(document).ready(function(){
var totalCount =  $("#totalCountHidden").text();
//$("#totalCountactual").text(totalCount);
var passCount =  $("#passCountHidden").text();
//$("#passCountactual").text(passCount);
var failCount =  $("#failCountHidden").text();
//$("#failCountactual").text(failCount);
var norunCount =  $("#norunCountHidden").text();
//$("#norunCountactual").text(norunCount);
var endtime = $("#endtimehidden").text();
$("#endtimeactual").text(endtime);
var runduration = $("#rundurationhidden").text();
$("#rundurationactual").text(runduration);

var analTot = [passCount * 1, failCount * 1, norunCount * 1]

var pass = analTot[0];
var fail = analTot[1];
var norun = analTot[2];


window.onload = function () {
	CanvasJS.addColorSet("greenShades",
                [//colorSet Array
                "#7fba00",
                "#d81e05",
                "#FFFF00"                
                ]);
	var chart = new CanvasJS.Chart("chartContainer",
	{
			colorSet: "greenShades",
		
		title:{
			text: "Details of Execution"
		},
		legend: {
			maxWidth: 500,
			itemWidth: 80,
			fontSize : 12,
			fontFamily : "GE Inspira",
			verticalAlign: "top",
			horizontalAlign: "center"
			
		},
		data: [
		{        
			type: "pie",
			indexLabelFontFamily: "GE Inspira",       
			indexLabelFontSize: 15,
			indexLabelFontWeight: "bold",
			startAngle:0,
			//indexLabelFontColor: "Blue",       
			indexLabelLineColor: "black", 
			indexLabelPlacement: "outside", 
			toolTipContent: "<strong>{name}: {y} Steps</strong>",
			showInLegend: true,
			indexLabel: "#percent%",
			dataPoints: [
				{ y: pass, name : "Passed" ,indexLabel: "Passed",indexLabelFontColor:"Green" ,legendMarkerType: "triangle"},
				{ y: fail, name : "Failed", indexLabel: "Failed" ,indexLabelFontColor:"Red",legendMarkerType: "square"},
				//{ y: norun, name :"No Run",indexLabel: "No Run" ,indexLabelFontColor:"Black",legendMarkerType: "circle"},
			]
		}
		]
	});
	chart.render();
}});
//***********************************************************************************************************************************************************************************
//Function Name        - javascript & Jquery functions to draw chart and handle popups in the HTML report
//Description 			- NA
//Input Parameters      	- NA
//Pre-Condition          - N/A
//Post - Condition:      - N/A
//Return Value           - NA
//Author                 - Gaurav  Saxena
//Date                   - 7 Sep 2015
//***********************************************************************************************************************************************************************************

$(document).keyup(function(e) {
  //alert(e.keyCode);

  if (e.keyCode == 27) $('.js-modal-close').click();   // esc
});
$(function(){

var appendthis =  ("<div class='modal-overlay js-modal-close'></div>");

	$('a[data-modal-id]').click(function(e) {
		e.preventDefault();
  //  $("body").append(appendthis);
   // $(".modal-overlay").fadeTo(500, 0.7);
    //$(".js-modalbox").fadeIn(500);
		var modalBox = $(this).attr('data-modal-id');
		$('#'+modalBox).fadeIn($(this).data());
	});  
//, .modal-overlay
		
$(".js-modal-close, .modal-overlay").click(function(e) {
	e.preventDefault();
    $(".modal-box").fadeOut(500, function() {
       // $(".modal-overlay").remove();
    });
 
});
 
$(window).resize(function() {
    $(".modal-box").css({
        top: ($(window).height() - $(".modal-box").outerHeight()) / 2,
        left: ($(window).width() - $(".modal-box").outerWidth()) / 2
    });
});
 
$(window).resize();
 
});